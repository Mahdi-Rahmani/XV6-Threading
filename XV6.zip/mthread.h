#include "types.h"
#include "param.h"
#include "syscall.h"
#include "traps.h"
#include "fs.h"
#include "mmu.h"

int stack[4096] __attribute__ ((aligned (4096)));

int thread_create(void (*fn) (void *), void *arg)
{
    int tid = clone(stack);
    //printf(1, "We are here");
    if (tid < 0)
    {
        return -1;
    }
    else if (tid == 0)
    {
        printf(1, "Here");
        fn(arg);
        printf(1, "###");
        free(stack);
        exit();
    }
    else
        return tid;
}

int thread_join(void)
{
    return join();
}